#!/usr/bin/env python
# coding: utf-8

# # Predicting structures
# 
# Running this block will predict crystal structures.
# 
# You need to prepare the input files and keep them in `chemical_compositions` folder. Names of the input file should be like this: `gnoa_<name of your compound>.in`. This block will save the results in the directory `results/results_<name of your compound>`.

# In[1]:


import os
from predict_structure import PredictStructure

folder_path = 'chemical_compositions'
file_paths = []

# Iterate over the files in the folder
for file_name in os.listdir(folder_path):
    # Create the full file path by joining the folder path and file name
    file_path = os.path.join(folder_path, file_name)
    
    # Add the file path to the list
    file_paths.append(file_path)

# Print the file paths
for file_path in file_paths:
    csp = PredictStructure(file_path)


# # Saving best structures
# 
# The above code saves several structures with different energies.
# 
# Running this block will search for the lowest energy structure and save the `.cif` files in the directory `results/best_structures`.

# In[2]:


import os
import shutil

results_folder = 'results'
best_structures_folder = os.path.join(results_folder, 'best_structures')

# Create the 'best_structures' folder if it doesn't exist
if not os.path.exists(best_structures_folder):
    os.makedirs(best_structures_folder)

# Iterate over the 'results' folders
for folder_name in os.listdir(results_folder):
    folder_path = os.path.join(results_folder, folder_name)
    if os.path.isdir(folder_path):
        # Look for the 'structures' folder inside each 'results' folder
        structures_folder = os.path.join(folder_path, 'structures')
        if os.path.exists(structures_folder):
            # Print the desired path format
            structures_path = os.path.join(results_folder, folder_name, 'structures')
            # print(structures_path)

            # Get a list of all .cif files in the directory
            cif_files = [file for file in os.listdir(structures_path) if file.endswith(".cif")]

            # Initialize variables to store the best structure information
            best_energy = float("inf")  # Set an initial high energy value
            best_structure = ""

            # Iterate over the .cif files and find the one with the lowest energy
            for cif_file in cif_files:
                file_name, file_extension = os.path.splitext(cif_file)
                if file_extension == ".cif":
                    parts = file_name.split("_")
                    if len(parts) >= 3:
                        energy = float(parts[2])
                        if energy < best_energy:
                            best_energy = energy
                            best_structure = cif_file

            # Print the best structure file name
            # print("Best Structure:", best_structure)

            # Copy the best structure file to the 'best_structures' folder
            if best_structure:
                source_path = os.path.join(structures_path, best_structure)
                destination_path = os.path.join(best_structures_folder, best_structure)
                shutil.copyfile(source_path, destination_path)
                # print("Best Structure saved to:", destination_path)

