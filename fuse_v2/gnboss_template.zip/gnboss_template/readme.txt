to install,

create a fresh anaconda environment, e.g.:

conda create --name gnboss python=3.6.13

activate the environment:

conda activate gnboss

then install the required packages:

python -m pip install -r requirements.txt
